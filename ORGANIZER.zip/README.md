# DeepVault

`DeepVault` is a deliberately vulnerable Android reverse-engineering CTF challenge intended for advanced mobile pentesters.

The app is designed around three hidden pivots:

- an exported `ContentProvider` with a non-obvious query contract
- an exported `BroadcastReceiver` that only unlocks state when the right payload is sent
- a JNI-backed final stage that requires contestants to reconstruct the bridge value used for native validation

The intended solve path works with stock `adb shell content query` and `adb shell am broadcast`.

The final flag format for the shipped build is `CTF{...}`.

## Build

1. Open the project in Android Studio Hedgehog or newer.
2. Let Android Studio generate the Gradle wrapper if needed.
3. Build a release APK and sign it with your organizer key.
4. Host the generated APK as the challenge artifact.

## Hosting Notes

- The player-facing flag is deterministic and static for the shipped source.
- A full organizer walkthrough is in [ORGANIZER.md](/C:/Users/sudha/Documents/Codex/2026-04-23-i-want-to-mobile-android-app/ORGANIZER.md).
- You can increase difficulty further by enabling R8 minification in the release build and stripping symbols from the native library.

## Intended Audience

This challenge assumes comfort with:

- `jadx`, `apktool`, and manifest triage
- `adb shell content`, `adb shell am`
- JNI/native reversing
- light Kotlin deobfuscation and crypto recreation
