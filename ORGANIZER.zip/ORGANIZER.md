# Organizer Guide

## Challenge Summary

`DeepVault` is a hard Android app challenge built for advanced solvers. The final unlock requires using Android platform surfaces and reverse engineering rather than a single static string search.

## Intended Solve Path

1. Inspect the manifest and enumerate exported components.
2. Reverse the provider contract in `HiddenRoutes.providerRoute()`.
3. Query the provider with the required projection and selection string to recover the first shard:
   - URI: `content://ctf.deepvault.provider/seed/a9f1f0c3/open`
   - projection must contain `operator`
   - selection must equal `copper`
4. Use the returned shard to derive the receiver payload:
   - `wire = shard.reversed() + ":73"`
   - `slot = 4`
5. Send an explicit broadcast to `ctf.deepvault.hidden.RelayReceiver`.
6. The app stores the second shard in app preferences.
7. Reverse `CryptoPuzzle.buildBridge()` and `native-lib.cpp`.
8. The expected decoded bridge string is `OBSIDIAN:MIRROR:mobile`.
9. The native library returns the third shard `ORBIT`.
10. Recreate the final token:
    - `sha256("OBSIDIAN|MIRROR|ORBIT|vault.mobile.2026").take(24)`
    - final format: `CTF{<24 hex chars>}`

## Final Flag

The shipped source validates against:

`CTF{07fe19034e7f5ebe59532331}`

## Suggested Distribution

- Ship only the signed release APK to players.
- Keep this organizer guide private.
- Use release minification for the real event build.

## Optional Hardening Before Release

- Turn `isMinifyEnabled` on for release.
- Strip JNI symbols from the final `.so`.
- Rename package and class identifiers before the event if you want fresh public artifacts.

## Example Interaction

Provider query:

```bash
adb shell content query \
  --uri content://ctf.deepvault.provider/seed/a9f1f0c3/open \
  --projection operator \
  --where copper
```

Broadcast:

```bash
adb shell am broadcast \
  -n ctf.deepvault/.hidden.RelayReceiver \
  --es wire NAIDISBO:73 \
  --ei slot 4
```

## Notes

- The anti-analysis checks are advisory and intended to create noise, not make the app unsolvable.
- If you customize the shards, update both Kotlin validation and this guide.

## Optional Player Hints

Use these only if you want staged hints during the event:

1. "The app trusts surfaces the launcher never touches."
2. "One secret is read, one is signaled, one is derived beyond Kotlin."
3. "The last step is assembly, not discovery."
