Java.perform(function() {
    setTimeout(function() {  // Delay for system stability
        try {
            // 1. Safely get the MainActivity class
            var MainActivity = Java.use('com.example.aidl.MainActivity');
            
            // 2. Verify the static method exists
            if (MainActivity.p) {
                // 3. Call the static verifier
                var expected = MainActivity.p();
                console.log("[+] Flag: " + expected);
            } else {
                console.log("[-] Method 'p()' not found!");
            }
        } catch (e) {
            console.log("[!] Critical Error: " + e);
        }
    }, 3000);  // 3-second delay
});