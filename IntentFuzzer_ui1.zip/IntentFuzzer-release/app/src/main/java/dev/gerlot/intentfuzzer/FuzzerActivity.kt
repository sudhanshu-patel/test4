package dev.gerlot.intentfuzzer

import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageInfo
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import dev.gerlot.intentfuzzer.core.FuzzLogger
import dev.gerlot.intentfuzzer.core.FuzzResult
import dev.gerlot.intentfuzzer.core.IntentFuzzerEngine
import dev.gerlot.intentfuzzer.fuzz.NullFuzzStrategy
import dev.gerlot.intentfuzzer.fuzz.ParcelableFuzzStrategy
import dev.gerlot.intentfuzzer.fuzz.RandomFuzzStrategy
import dev.gerlot.intentfuzzer.util.AppInfo
import dev.gerlot.intentfuzzer.util.ComponentInfo
import dev.gerlot.intentfuzzer.util.SerializableTest
import dev.gerlot.intentfuzzer.util.Utils
import kotlinx.coroutines.launch

class FuzzerActivity : AppCompatActivity() {

    private var cmpTypes = ipcTypesToNames.values.toList()
    private var currentType = cmpTypes[0]

    private var components: List<ComponentInfo> = emptyList()
    private var pkgInfo: PackageInfo? = null

    private var cmpListView: ListView? = null
    private var typeGroup: MaterialButtonToggleGroup? = null

    private var fuzzNullBtn: Button? = null
    private var fuzzSerBtn: Button? = null
    private var fuzzAdvBtn: Button? = null
    private var viewLogsBtn: Button? = null
    private var onlyExportedSwitch: Switch? = null

    private val logger by lazy { FuzzLogger(this) }
    private val engine by lazy { IntentFuzzerEngine(this) }

    private var cmpAdapter: ComponentAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fuzzer)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val info: AppInfo? = intent.getParcelableExtra(Utils.APPINFO_KEY)
        if (info == null) {
            Toast.makeText(this, "Package info missing", Toast.LENGTH_LONG).show()
            return
        }

        pkgInfo = info.packageInfo
        title = info.appName

        initView()
        initTypeGroup()
        updateComponents(currentType)
    }

    override fun onOptionsItemSelected(i: MenuItem): Boolean {
        if (i.itemId == android.R.id.home) {
            onBackPressedDispatcher.onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(i)
    }

    private fun initView() {
        cmpListView = findViewById(R.id.cmp_listview)
        typeGroup = findViewById(R.id.type_select)

        fuzzNullBtn = findViewById(R.id.fuzz_all_null)
        fuzzSerBtn = findViewById(R.id.fuzz_all_se)
        fuzzAdvBtn = findViewById(R.id.fuzz_all_adv)
        viewLogsBtn = findViewById(R.id.view_logs)
        onlyExportedSwitch = findViewById(R.id.only_exported_switch)

        cmpListView?.setOnItemClickListener { _, _, pos, _ ->
            val cmp = components[pos]
            val i = Intent().apply { setComponent(cmp.name) }
            logAndSend(cmp, "MANUAL-NULL", i)
        }

        cmpListView?.setOnItemLongClickListener { _, _, pos, _ ->
            val cmp = components[pos]
            val i = Intent().apply {
                setComponent(cmp.name)
                putExtra("test", SerializableTest())
            }
            logAndSend(cmp, "MANUAL-SERIALIZABLE", i)
            true
        }

        fuzzNullBtn?.setOnClickListener {
            bulk("BULK-NULL") { cmp ->
                Intent().apply { setComponent(cmp.name) }
            }
        }

        fuzzSerBtn?.setOnClickListener {
            bulk("BULK-SERIALIZABLE") { cmp ->
                Intent().apply {
                    setComponent(cmp.name)
                    putExtra("test", SerializableTest())
                }
            }
        }

        fuzzAdvBtn?.setOnClickListener {
            runAdvanced()
        }

        viewLogsBtn?.setOnClickListener {
            startActivity(Intent(this, FuzzResultActivity::class.java))
        }

        onlyExportedSwitch?.setOnCheckedChangeListener { _, _ ->
            updateComponents(currentType)
        }
    }

    private fun logAndSend(cmp: ComponentInfo, strategy: String, intent: Intent) {
        val payload = payloadOf(intent)

        logger.append(
            FuzzResult(
                pkgInfo!!.packageName,
                cmp.name.className,
                strategy,
                0,
                "TRY",
                payload
            )
        )

        if (onlyExportedSwitch!!.isChecked && !cmp.exported) {
            logger.append(
                FuzzResult(
                    pkgInfo!!.packageName,
                    cmp.name.className,
                    strategy,
                    0,
                    "SKIPPED_NOT_EXPORTED",
                    payload
                )
            )
            Toast.makeText(this, "Skipped (not exported)", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            startActivity(intent)
            logger.append(
                FuzzResult(
                    pkgInfo!!.packageName,
                    cmp.name.className,
                    strategy,
                    0,
                    "SUCCESS",
                    payload
                )
            )
        } catch (e: Exception) {
            logger.append(
                FuzzResult(
                    pkgInfo!!.packageName,
                    cmp.name.className,
                    strategy,
                    0,
                    "FAILED: ${e.message}",
                    payload
                )
            )
            Toast.makeText(this, "Send Failed", Toast.LENGTH_SHORT).show()
        }
    }

    private fun bulk(strategy: String, creator: (ComponentInfo) -> Intent) {
        components.forEach { cmp ->
            val intent = creator(cmp)
            val payload = payloadOf(intent)

            logger.append(
                FuzzResult(pkgInfo!!.packageName, cmp.name.className, strategy, 0, "TRY", payload)
            )

            if (onlyExportedSwitch!!.isChecked && !cmp.exported) {
                logger.append(
                    FuzzResult(pkgInfo!!.packageName, cmp.name.className, strategy, 0, "SKIPPED_NOT_EXPORTED", payload)
                )
                return@forEach
            }

            val success = try {
                startActivity(intent)
                true
            } catch (e: Exception) {
                false
            }

            logger.append(
                FuzzResult(
                    pkgInfo!!.packageName,
                    cmp.name.className,
                    strategy,
                    0,
                    if (success) "SUCCESS" else "FAILED",
                    payload
                )
            )
        }
        Toast.makeText(this, "$strategy completed", Toast.LENGTH_SHORT).show()
    }

    private fun runAdvanced() {
        lifecycleScope.launch {

            val strategies = listOf(
                NullFuzzStrategy(),
                RandomFuzzStrategy(),
                ParcelableFuzzStrategy()
            )

            for (cmp in components) {

                if (onlyExportedSwitch!!.isChecked && !cmp.exported) {
                    logger.append(
                        FuzzResult(pkgInfo!!.packageName, cmp.name.className, "ADVANCED", 0, "SKIPPED_NOT_EXPORTED")
                    )
                    continue
                }

                engine.fuzzComponent(
                    pkgInfo!!.packageName,
                    cmp.name,
                    strategies,
                    attempts = 5
                ) { result ->
                    logger.append(result)
                }
            }

            Toast.makeText(this@FuzzerActivity, "Advanced fuzz done", Toast.LENGTH_SHORT).show()
        }
    }

    private fun payloadOf(intent: Intent): String {
        val extras = intent.extras ?: return "{}"
        val map = mutableMapOf<String, Any?>()
        for (k in extras.keySet()) map[k] = extras.get(k)
        return map.toString()
    }

    private fun initTypeGroup() {
        typeGroup!!.removeAllViews()
        cmpTypes.forEach { type ->
            val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
            b.text = type
            typeGroup!!.addView(b)
        }

        typeGroup!!.addOnButtonCheckedListener { _, id, checked ->
            if (!checked) return@addOnButtonCheckedListener
            cmpTypes.forEachIndexed { idx, t ->
                if ((typeGroup!!.getChildAt(idx) as MaterialButton).id == id) {
                    currentType = t
                    updateComponents(t)
                }
            }
        }

        (typeGroup!!.getChildAt(0) as MaterialButton).isChecked = true
    }

    private fun updateComponents(typeName: String?) {
        components = getComponents(typeName)

        cmpAdapter = ComponentAdapter(this, components)
        cmpListView!!.adapter = cmpAdapter

        val vis = if (components.isNotEmpty()) View.VISIBLE else View.INVISIBLE

        fuzzNullBtn!!.visibility = vis
        fuzzSerBtn!!.visibility = vis
        fuzzAdvBtn!!.visibility = vis
        viewLogsBtn!!.visibility = vis
    }

    private fun getComponents(typeName: String?): List<ComponentInfo> {
        val type = ipcNamesToTypes[typeName]
        if (type == null || pkgInfo == null) return emptyList()

        val infos = when (type) {
            Utils.ACTIVITIES -> pkgInfo!!.activities
            Utils.RECEIVERS -> pkgInfo!!.receivers
            Utils.SERVICES -> pkgInfo!!.services
            else -> pkgInfo!!.activities
        } ?: return emptyList()

        return infos.map {
            ComponentInfo(
                type,
                ComponentName(pkgInfo!!.packageName, it.name),
                exported = it.exported
            )

        }
    }

    companion object {
        private val ipcTypesToNames = sortedMapOf(
            Utils.ACTIVITIES to "Activities",
            Utils.RECEIVERS to "Receivers",
            Utils.SERVICES to "Services"
        )

        private val ipcNamesToTypes = ipcTypesToNames.map { (k, v) -> v to k }.toMap()
    }
}
