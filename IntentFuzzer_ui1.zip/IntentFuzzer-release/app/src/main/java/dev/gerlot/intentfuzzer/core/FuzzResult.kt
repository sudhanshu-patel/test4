package dev.gerlot.intentfuzzer.core

import org.json.JSONObject

data class FuzzResult(
    val packageName: String,
    val componentName: String,
    val strategy: String,
    val attempt: Int,
    val status: String,
    val payload: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): String {
        val o = JSONObject()
        o.put("package", packageName)
        o.put("component", componentName)
        o.put("strategy", strategy)
        o.put("attempt", attempt)
        o.put("status", status)
        if (payload != null) o.put("payload", payload)
        o.put("timestamp", timestamp)
        return o.toString()
    }

    override fun toString(): String {
        return "FuzzResult($componentName, strategy=$strategy, attempt=$attempt, status=$status, payload=$payload)"
    }
}
