package dev.gerlot.intentfuzzer.util

import android.content.pm.PackageInfo
import android.os.Parcel
import android.os.Parcelable

data class AppInfo(
    val appName: String,
    val packageName: String,
    val packageInfo: PackageInfo
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readParcelable(PackageInfo::class.java.classLoader)!!
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(appName)
        parcel.writeString(packageName)
        parcel.writeParcelable(packageInfo, flags)
    }

    override fun describeContents(): Int = 0

    companion object CREATOR : Parcelable.Creator<AppInfo> {
        override fun createFromParcel(parcel: Parcel): AppInfo = AppInfo(parcel)
        override fun newArray(size: Int): Array<AppInfo?> = arrayOfNulls(size)
    }
}
