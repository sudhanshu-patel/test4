package dev.gerlot.intentfuzzer.util

import android.content.ComponentName

data class ComponentInfo(
    val type: Int,
    val name: ComponentName,
    val exported: Boolean = false
)
