package dev.gerlot.intentfuzzer.fuzz

import android.content.Intent
import android.os.Parcel
import android.os.Parcelable
import org.json.JSONObject

class EvilParcelable(val value: String) : Parcelable {
    constructor(p: Parcel) : this(p.readString() ?: "")
    override fun writeToParcel(p: Parcel, flags: Int) = p.writeString(value)
    override fun describeContents() = 0
    companion object CREATOR : Parcelable.Creator<EvilParcelable> {
        override fun createFromParcel(p: Parcel) = EvilParcelable(p)
        override fun newArray(size: Int) = arrayOfNulls<EvilParcelable?>(size)
    }
}

class ParcelableFuzzStrategy : FuzzStrategy {

    override val name = "ParcelableFuzz"

    override suspend fun prepare(base: Intent): Intent {
        return Intent(base).apply {
            putExtra("evil_parcel", EvilParcelable("payload-" + System.currentTimeMillis()))
        }
    }

    override fun payload(intent: Intent): String {
        val p = intent.getParcelableExtra<EvilParcelable>("evil_parcel")
        val j = JSONObject()
        j.put("evil_parcel", p?.value ?: "")
        return j.toString()
    }
}
