package dev.gerlot.intentfuzzer

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * Minimal modern home screen (Option 3).
 * - Select App -> opens AppListActivity
 * - Open Fuzzer -> opens FuzzerActivity for last-selected app (saved in prefs)
 * - Settings -> placeholder (no About page)
 */
class MainActivity : AppCompatActivity() {

    private lateinit var selectAppBtn: MaterialButton
    private lateinit var openFuzzerBtn: MaterialButton
    private lateinit var settingsBtn: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        selectAppBtn = findViewById(R.id.btn_select_app)
        openFuzzerBtn = findViewById(R.id.btn_open_fuzzer)
        settingsBtn = findViewById(R.id.btn_settings)

        selectAppBtn.setOnClickListener {
            startActivity(Intent(this, AppListActivity::class.java))
        }

        openFuzzerBtn.setOnClickListener {
            val pkg = getSharedPreferences("intentfuzzer", MODE_PRIVATE).getString("last_target_pkg", null)
            val appLabel = getSharedPreferences("intentfuzzer", MODE_PRIVATE).getString("last_target_label", null)
            if (pkg == null) {
                Toast.makeText(this, "No app selected. Tap Select App first.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(this, FuzzerActivity::class.java).apply {
                // FuzzerActivity expects an AppInfo parcelable under Utils.APPINFO_KEY.
                // We'll store minimal info using AppInfoActivity: launch AppInfoActivity which forwards.
                putExtra("target_pkg", pkg)
                // To stay compatible, start AppInfoActivity which will load PackageInfo and redirect to FuzzerActivity.
            }
            // Start AppInfoActivity which will create AppInfo and open FuzzerActivity
            startActivity(Intent(this, AppInfoActivity::class.java).apply {
                putExtra("launch_from_main", true)
                putExtra("package_name", pkg)
                putExtra("app_label", appLabel)
            })
        }

        settingsBtn.setOnClickListener {
            Toast.makeText(this, "Settings placeholder — no About page", Toast.LENGTH_SHORT).show()
        }
    }
}
