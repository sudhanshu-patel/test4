package dev.gerlot.intentfuzzer

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView

class AppListAdapter(context: Context, private val items: List<ApplicationInfo>, private val pm: PackageManager) :
    ArrayAdapter<ApplicationInfo>(context, R.layout.app_list_item, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val v = convertView ?: LayoutInflater.from(context).inflate(R.layout.app_list_item, parent, false)
        val icon = v.findViewById<ImageView>(R.id.app_icon)
        val title = v.findViewById<TextView>(R.id.app_title)
        val ai = items[position]
        icon.setImageDrawable(pm.getApplicationIcon(ai))
        title.text = pm.getApplicationLabel(ai)
        return v
    }
}
