package dev.gerlot.intentfuzzer

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar

/**
 * Shows a simple list of user-installed apps. Selecting one saves it as "last_target_*"
 * and launches AppInfoActivity which creates an AppInfo and then opens FuzzerActivity.
 */
class AppListActivity : AppCompatActivity() {

    private lateinit var pkgManager: PackageManager
    private lateinit var listView: ListView
    private lateinit var adapter: AppListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_list)

        setSupportActionBar(findViewById<MaterialToolbar>(R.id.app_list_toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        pkgManager = packageManager
        listView = findViewById(R.id.app_list_view)

        val apps = pkgManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 } // user apps only
            .sortedBy { pkgManager.getApplicationLabel(it).toString().lowercase() }

        adapter = AppListAdapter(this, apps, pkgManager)
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val ai = apps[position]
            val pkg = ai.packageName
            val label = pkgManager.getApplicationLabel(ai).toString()
            // save as last target
            getSharedPreferences("intentfuzzer", MODE_PRIVATE)
                .edit()
                .putString("last_target_pkg", pkg)
                .putString("last_target_label", label)
                .apply()

            // open AppInfoActivity which will prepare AppInfo and forward to FuzzerActivity
            startActivity(Intent(this, AppInfoActivity::class.java).apply {
                putExtra("package_name", pkg)
            })
        }
    }
}
