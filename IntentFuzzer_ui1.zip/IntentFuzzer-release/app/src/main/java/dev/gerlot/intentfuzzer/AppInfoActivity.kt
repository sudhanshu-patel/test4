package dev.gerlot.intentfuzzer

import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import dev.gerlot.intentfuzzer.util.AppInfo
import dev.gerlot.intentfuzzer.util.Utils


/**
 * Minimal AppInfo loader that builds AppInfo and then starts FuzzerActivity.
 * If launched with "launch_from_main" it will forward directly to FuzzerActivity.
 */
class AppInfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app_info)

        val pkg = intent.getStringExtra("package_name") ?: intent.getStringExtra("target_pkg")
        if (pkg == null) {
            Toast.makeText(this, "No package specified", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val pm = packageManager
        val pi = try { pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS) } catch (e: Exception) { null }

        if (pi == null) {
            Toast.makeText(this, "Cannot load package info", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val label = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        val appInfo = AppInfo(label, pkg, pi)

        // show minimal UI
        findViewById<TextView>(R.id.app_info_title).text = label
        findViewById<TextView>(R.id.app_info_pkg).text = pkg
        findViewById<Button>(R.id.app_info_open_fuzzer).setOnClickListener {
            // start FuzzerActivity, passing AppInfo parcelable
            val i = Intent(this, FuzzerActivity::class.java)
            i.putExtra(Utils.APPINFO_KEY, appInfo)
            startActivity(i)
            finish()
        }

        // If invoked to forward from MainActivity, auto open fuzzer
        if (intent.getBooleanExtra("launch_from_main", false)) {
            // small delay might be useful but we forward immediately
            val i = Intent(this, FuzzerActivity::class.java)
            i.putExtra(Utils.APPINFO_KEY, appInfo)
            startActivity(i)
            finish()
        }
    }
}
