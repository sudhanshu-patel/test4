package dev.gerlot.intentfuzzer

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dev.gerlot.intentfuzzer.core.FuzzLogger

class FuzzResultActivity : AppCompatActivity() {

    private lateinit var logger: FuzzLogger
    private lateinit var adapter: LogAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fuzz_result)

        logger = FuzzLogger(this)

        val recycler = findViewById<RecyclerView>(R.id.fuzzLogList)
        val exportBtn = findViewById<Button>(R.id.exportLogs)
        val clearBtn = findViewById<Button>(R.id.clearLogs)

        adapter = LogAdapter()
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        adapter.submit(logger.getAll())

        exportBtn.setOnClickListener {
            val f = logger.export()
            Toast.makeText(this, "Exported to: ${f.absolutePath}", Toast.LENGTH_LONG).show()
        }

        clearBtn.setOnClickListener {
            logger.clear()
            adapter.submit(logger.getAll())
            Toast.makeText(this, "Cleared logs", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        adapter.submit(logger.getAll())
    }
}
