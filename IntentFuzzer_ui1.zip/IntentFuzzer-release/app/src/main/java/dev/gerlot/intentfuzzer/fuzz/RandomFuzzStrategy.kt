package dev.gerlot.intentfuzzer.fuzz

import android.content.Intent
import android.os.Bundle
import org.json.JSONObject
import kotlin.random.Random

class RandomFuzzStrategy : FuzzStrategy {

    override val name = "RandomFuzz"

    private val r = Random(System.currentTimeMillis())

    override suspend fun prepare(base: Intent): Intent {
        val b = Bundle()
        b.putString("rand_str", (1..10).map { ('a'..'z').random(r) }.joinToString(""))
        b.putInt("rand_int", r.nextInt())
        b.putBoolean("rand_bool", r.nextBoolean())

        return Intent(base).apply { replaceExtras(b) }
    }

    override fun payload(intent: Intent): String {
        val j = JSONObject()
        intent.extras?.keySet()?.forEach { k ->
            j.put(k, intent.extras!!.get(k).toString())
        }
        return j.toString()
    }
}
