package dev.gerlot.intentfuzzer.core

import android.content.Context
import android.util.Log
import java.io.File

class FuzzLogger(private val ctx: Context) {

    private val logDir = File(ctx.filesDir, "fuzz_logs").apply { if (!exists()) mkdirs() }
    private val logFile = File(logDir, "fuzz_log.jsonl")

    fun append(result: FuzzResult) {
        try {
            val line = result.toJson()
            logFile.appendText(line + "\n")
            Log.d("FUZZ_LOGGER", "Wrote: $line")
        } catch (e: Exception) {
            Log.e("FUZZ_LOGGER", "append error", e)
        }
    }

    fun getAll(): List<String> {
        return try {
            if (!logFile.exists()) return emptyList()
            logFile.readLines()
        } catch (e: Exception) {
            Log.e("FUZZ_LOGGER", "readAll error", e)
            emptyList()
        }
    }

    fun export(): File {
        val out = File(logDir, "fuzz_export_${System.currentTimeMillis()}.json")
        out.writeText("[\n" + getAll().joinToString(",\n") + "\n]")
        return out
    }

    fun clear() {
        try {
            if (logFile.exists()) logFile.delete()
            logFile.createNewFile()
        } catch (e: Exception) {
            Log.e("FUZZ_LOGGER", "clear error", e)
        }
    }
}
