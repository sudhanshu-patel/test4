package dev.gerlot.intentfuzzer

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject

class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {

    private val items = ArrayList<String>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.logTitle)
        val body: TextView = v.findViewById(R.id.logBody)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.log_item, parent, false)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, pos: Int) {
        val raw = items[pos]
        // try to pretty print
        try {
            val j = JSONObject(raw)
            val status = j.optString("status")
            val comp = j.optString("component")
            val strat = j.optString("strategy")
            val payload = if (j.has("payload")) j.optString("payload") else ""
            holder.title.text = "$comp • $strat • $status"
            holder.body.text = (if (payload.isNotBlank()) "payload: $payload\n" else "") + "raw: $raw"
        } catch (e: Exception) {
            holder.title.text = "log"
            holder.body.text = raw
        }
    }

    fun submit(list: List<String>) {
        items.clear()
        items.addAll(list.reversed()) // newest first
        notifyDataSetChanged()
    }
}
