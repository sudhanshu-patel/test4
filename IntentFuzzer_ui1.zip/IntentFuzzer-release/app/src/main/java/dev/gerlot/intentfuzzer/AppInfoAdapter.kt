package dev.gerlot.intentfuzzer

import android.content.Context
import android.content.pm.PackageManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import dev.gerlot.intentfuzzer.util.AppInfo

/**
 * Adapter for showing selected app details (name + icon).
 * This version no longer uses appInfo.appIcon because
 * the new AppInfo class stores only PackageInfo.
 */
class AppInfoAdapter(
    context: Context,
    private val items: List<AppInfo>,
    private val pm: PackageManager
) : ArrayAdapter<AppInfo>(context, R.layout.app_list_item, items) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.app_list_item, parent, false)

        val icon = view.findViewById<ImageView>(R.id.app_icon)
        val title = view.findViewById<TextView>(R.id.app_title)
        val item = items[position]

        // Load icon using package manager
        icon.setImageDrawable(pm.getApplicationIcon(item.packageName))

        // Load label
        title.text = item.appName

        return view
    }
}
