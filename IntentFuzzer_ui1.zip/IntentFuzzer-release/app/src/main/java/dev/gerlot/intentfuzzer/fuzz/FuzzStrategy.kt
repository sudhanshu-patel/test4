package dev.gerlot.intentfuzzer.fuzz

import android.content.Intent

interface FuzzStrategy {
    val name: String

    suspend fun prepare(base: Intent): Intent

    /**
     * Convert Intent extras to a readable payload string
     */
    fun payload(intent: Intent): String {
        val extras = intent.extras ?: return "{}"
        val map = mutableMapOf<String, Any?>()
        for (k in extras.keySet()) map[k] = extras.get(k)
        return map.toString()
    }
}
