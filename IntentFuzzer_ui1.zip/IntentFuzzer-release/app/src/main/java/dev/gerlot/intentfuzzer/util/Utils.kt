package dev.gerlot.intentfuzzer.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager

object Utils {

    const val ALL_APPS: Int = 0
    const val SYSTEM_APPS: Int = 1
    const val NONSYSTEM_APPS: Int = 2
    const val ABOUT: Int = 3

    const val MSG_PROCESSING: Int = 0
    const val MSG_DONE: Int = 1
    const val MSG_ERROR: Int = 2

    const val ACTIVITIES: Int = 0
    const val RECEIVERS: Int = 1
    const val SERVICES: Int = 2

    const val APPINFO_KEY: String = "appinfo"
    const val APPTYPE_KEY: String = "apptype"


    /**
     * Returns a sorted list of AppInfo for apps based on SYSTEM/NON-SYSTEM/ALL filters.
     */
    fun getPackageInfo(context: Context, type: Int): List<AppInfo> {
        val list: MutableList<AppInfo> = ArrayList()

        val packages = context.packageManager.getInstalledPackages(
            PackageManager.GET_DISABLED_COMPONENTS or
                    PackageManager.GET_ACTIVITIES or
                    PackageManager.GET_RECEIVERS or
                    PackageManager.GET_INSTRUMENTATION or
                    PackageManager.GET_SERVICES
        )

        for (pkg in packages) {
            val isSystem = (pkg.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

            when (type) {
                SYSTEM_APPS -> if (isSystem) list.add(createAppInfo(context, pkg))
                NONSYSTEM_APPS -> if (!isSystem) list.add(createAppInfo(context, pkg))
                else -> list.add(createAppInfo(context, pkg))
            }
        }

        return list.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.appName })
    }


    /**
     * Builds AppInfo from PackageInfo using the NEW immutable constructor.
     */
    private fun createAppInfo(context: Context, pkg: PackageInfo): AppInfo {
        val pm = context.packageManager
        val label = pkg.applicationInfo.loadLabel(pm).toString()

        return AppInfo(
            appName = label,
            packageName = pkg.packageName,
            packageInfo = pkg
        )
    }
}
