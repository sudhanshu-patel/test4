package dev.gerlot.intentfuzzer.fuzz

import android.content.Intent

class NullFuzzStrategy : FuzzStrategy {

    override val name = "NullFuzz"

    override suspend fun prepare(base: Intent): Intent {
        return Intent(base).apply { replaceExtras(null) }
    }

    override fun payload(intent: Intent): String = "{}"
}
