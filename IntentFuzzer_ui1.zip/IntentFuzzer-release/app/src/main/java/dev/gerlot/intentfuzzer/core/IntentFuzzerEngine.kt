package dev.gerlot.intentfuzzer.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.Log
import dev.gerlot.intentfuzzer.fuzz.FuzzStrategy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class IntentFuzzerEngine(private val ctx: Context) {

    /**
     * Fuzz component using multiple strategies
     * @param packageName - target package
     * @param component   - target component
     * @param strategies  - list of fuzz strategies
     * @param attempts    - per-strategy attempt count (THIS is required!)
     * @param callback    - FuzzResult callback
     */
    suspend fun fuzzComponent(
        packageName: String,
        component: ComponentName,
        strategies: List<FuzzStrategy>,
        attempts: Int,
        callback: (FuzzResult) -> Unit
    ) {
        withContext(Dispatchers.IO) {

            val base = Intent().apply { setComponent(component) }

            strategies.forEach { strategy ->
                repeat(attempts) { attemptIndex ->

                    val prepared = try {
                        strategy.prepare(base)
                    } catch (e: Exception) {
                        callback(
                            FuzzResult(
                                packageName,
                                component.className,
                                strategy.name,
                                attemptIndex,
                                "FAILED: prepare_exception: ${e.message}",
                                payload = "{}"
                            )
                        )
                        return@repeat
                    }

                    val payload = strategy.payload(prepared)

                    // Log TRY event
                    callback(
                        FuzzResult(
                            packageName,
                            component.className,
                            strategy.name,
                            attemptIndex,
                            "TRY",
                            payload
                        )
                    )

                    try {
                        sendIntent(prepared)
                        callback(
                            FuzzResult(
                                packageName,
                                component.className,
                                strategy.name,
                                attemptIndex,
                                "SUCCESS",
                                payload
                            )
                        )
                    } catch (e: Exception) {
                        callback(
                            FuzzResult(
                                packageName,
                                component.className,
                                strategy.name,
                                attemptIndex,
                                "FAILED: ${e::class.java.simpleName}: ${e.message}",
                                payload
                            )
                        )
                    }
                }
            }
        }
    }

    /**
     * Try sending as Activity, then Broadcast, then Service.
     * Throw if all fail.
     */
    private fun sendIntent(intent: Intent) {
        var lastEx: Exception? = null

        try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            return
        } catch (e: Exception) {
            lastEx = e
        }

        try {
            ctx.sendBroadcast(intent)
            return
        } catch (e: Exception) {
            lastEx = e
        }

        try {
            ctx.startService(intent)
            return
        } catch (e: Exception) {
            lastEx = e
        }

        throw lastEx ?: RuntimeException("Unknown error sending intent")
    }
}
