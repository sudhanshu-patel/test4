@echo off
setlocal
cd /d "%~dp0"

echo.
echo Installing APKinspector dependencies...
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo Python was not found. Install Python 3.11 or newer from https://www.python.org/downloads/windows/
  echo Make sure "Add python.exe to PATH" is selected during installation.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  python -m venv .venv
)

".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt

echo.
echo APKinspector is installed. Run run_apkinspector.bat to start the app.
pause
