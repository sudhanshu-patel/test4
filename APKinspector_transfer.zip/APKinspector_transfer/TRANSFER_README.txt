APKinspector Transfer Package
=============================

How to use on another Windows machine:

1. Copy this entire APKinspector_transfer folder to the other machine.
2. Make sure Python 3.11 or newer is installed.
   Download: https://www.python.org/downloads/windows/
   During install, select "Add python.exe to PATH".
3. Double-click install_windows.bat.
4. After installation finishes, double-click run_apkinspector.bat.

What this package includes:

- APKinspector application source
- Requirements file
- Windows install script
- Windows run script
- README

What this package does not include:

- Existing scan database
- Uploaded APK archive folders
- Local virtual environment from the original machine

The other machine will create its own apkinspector.db and apk_scans folder when the app is used.
