# APKinspector

APKinspector is a Windows desktop application for security testing Android APK files. It imports APK metadata into a local SQLite database, asks for a PSS ID for every scan, archives each uploaded APK in a managed folder, and flags StrandHogg Attack / Task Affinity Vulnerability indicators found in the Android manifest.

## Features

- Modern Tkinter desktop UI for Windows
- Upload and inspect `.apk` files
- Local SQLite history database
- Per-upload PSS ID capture and search
- Package-folder grouping in the APK database, with each scan nested under its package name
- Version number shown directly in the APK database
- Delete option for removing a selected scan
- Timestamped APK archive folders for repeat uploads of the same app
- Android package, app label, version, minimum SDK, target SDK, and activity inventory
- Minimum supported Android version mapping from SDK numbers
- Filters for package/app/APK/PSS ID, minimum Android version, minimum SDK, and StrandHogg risk
- Light and dark UI modes
- Static StrandHogg/task-affinity checks for exported launchable activities, custom `taskAffinity`, risky launch modes, and `allowTaskReparenting`
- Test-case output for StrandHogg 1.0 manifest review and StrandHogg 2.0 runtime review leads
- DEX string scan for runtime indicators such as `startActivities()`, foreground-app monitoring APIs, `AccessibilityService`, `JobScheduler`, and task-launch flags

## Setup

```powershell
cd C:\Users\sudha\Documents\Codex\2026-04-17-create-a-python-application-that-has\APKinspector
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python .\apkinspector.py
```

## Notes

StrandHogg/task-affinity detection is static analysis, not a full exploit proof. APKinspector highlights risky manifest patterns commonly associated with task hijacking and StrandHogg-style abuse. Treat findings as security-testing leads that should be confirmed with dynamic testing on a lab device.

Uploaded APKs are copied into `apk_scans\<package>\<PSS ID>\<timestamp>\` so later uploads of the same application are retained as separate scan artifacts under the same package folder.

## StrandHogg Test Coverage

APKinspector maps each scan to test cases inspired by the Redfox Security StrandHogg writeups:

- Manifest-driven StrandHogg 1.0 indicators: non-empty `taskAffinity`, risky `singleTask` or `singleInstance` launch mode, and `allowTaskReparenting`.
- Exported launcher activity review: exported entry points that can be placed in a task stack.
- Legacy Android coverage: minimum SDK below Android 9 should be tested on older lab devices.
- Background launch coverage: target SDK below Android 10 should be checked for background UI launch behavior.
- Runtime StrandHogg 2.0 leads: DEX string indicators for crafted activity launches, foreground monitoring, and dynamic intent chains.

Static results are intended to drive lab validation with ADB, task stack inspection, and, where needed, runtime hooks for `startActivities()`.
