@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Running installer first...
  call install_windows.bat
)

".venv\Scripts\python.exe" apkinspector.py
